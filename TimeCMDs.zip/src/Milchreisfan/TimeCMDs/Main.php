<?php

/*
*	TimeCMDs - By Milchreisfan
*	GitHub: https://github.com/Milchreisfan/
*/

declare(strict_types=1);

namespace Milchreisfan\TimeCMDs;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;

class Main extends PluginBase implements Listener {

    public function onEnable() {
        $this->getLogger()->info("TimeCMDs ist aufgewacht! - By Milchreisfan");
    }
    public function onDisable() {
        $this->getLogger()->error("TimeCMDs ist eingeschlafen! - Error - Kontaktiere Milchreisfan bei GitHub!");
    }
    public $fts;

    public function onCommand(CommandSender $sender, Command $cmd, string $label, array $args): bool {
        
        $fts = "[CMD]";
        $this->fts = $fts;

        if($cmd->getName() == "day") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("day.cmd")) {
                    $sender->getLevel()->setTime(1000);
                    $sender->sendMessage("§l§o§bTimeCMDs §3>§r §fDie Zeit wurde geändert zu Tag!");
                } else {
                    $sender->sendMessage("§l§o§bTimeCMDs §3§r §cDu hast keine Rechte für diesen Befehl!");
                    return true;
                }
            }
            return true;
        }
        if($cmd->getName() == "night") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("night.cmd")) {
                    $sender->getLevel()->setTime(16000);
                    $sender->sendMessage("§l§o§bTimeCMDs §3>§r §fDie Zeit wurde geändert zu Nacht!");
                } else {
                    $sender->sendMessage("§l§o§bTimeCMDs §3§r §cDu hast keine Rechte für diesen Befehl!");
                    return true;
                }
            }
            return true;
        }
        if($cmd->getName() == "sunrise") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("sunrise.cmd")) {
                    $sender->getLevel()->setTime(23000);
                    $sender->sendMessage("§l§o§bTimeCMDs §3>§r §fDie Zeit wurde geändert zu Sonnenaufgang!");
                } else {
                    $sender->sendMessage("§l§o§bTimeCMDs §3§r §cDu hast keine Rechte für diesen Befehl!");
                    return true;
                }
            }
            return true;
        }
        if($cmd->getName() == "sunset") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("sunset.cmd")) {
                    $sender->getLevel()->setTime(12000);
                    $sender->sendMessage("§l§o§bTimeCMDs §3>§r §fDie Zeit wurde geändert zu Sonnenuntergang!");
                } else {
                    $sender->sendMessage("§l§o§bTimeCMDs §3§r §cDu hast keine Rechte für diesen Befehl!");
                    return true;
                }
            }
            return true;
        }
        if($cmd->getName() == "noon") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("noon.cmd")) {
                    $sender->getLevel()->setTime(6000);
                    $sender->sendMessage("§l§o§bTimeCMDs §3>§r §fDie Zeit wurde geändert zu Sonnenuntergang!");
                } else {
                    $sender->sendMessage("§l§o§bTimeCMDs §3§r §fDu hast keine Rechte für diesen Befehl!");
                    return true;
                }
            }
            return true;
        }
        if($cmd->getName() == "midnight") {
            if ($sender instanceof Player) {
                if ($sender->hasPermission("midnight.cmd")) {
                    $sender->getLevel()->setTime(18000);
                    $sender->sendMessage("§l§o§bTimeCMDs §3>§r §fDie Zeit wurde geändert zu Mitternacht!");
                } else {
                    $sender->sendMessage("§l§o§bTimeCMDs §3§r §fDu hast keine Rechte für diesen Befehl!");
                    return true;
                }
            }
            return true;
        }
    }
}